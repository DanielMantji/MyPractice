﻿using System;
using System.Collections.Generic;
using System.Linq;

class Ingredient
{
    public string Name { get; set; }
    public double Quantity { get; set; }
    public string Unit { get; set; }
    public int Calories { get; set; }
    public FoodGroup FoodGroup { get; set; }
}

class Step
{
    public string Description { get; set; }
}

class Recipe
{
    public string Name { get; set; }
    private List<Ingredient> ingredients = new List<Ingredient>();
    private List<Step> steps = new List<Step>();

    public void AddIngredient(string name, double quantity, string unit, int calories, FoodGroup foodGroup)
    {
        ingredients.Add(new Ingredient { Name = name, Quantity = quantity, Unit = unit, Calories = calories, FoodGroup = foodGroup });
    }

    public void AddStep(string description)
    {
        steps.Add(new Step { Description = description });
    }

    public void DisplayRecipe()
    {
        Console.WriteLine($"Recipe: {Name}");
        Console.WriteLine("Ingredients:");
        foreach (var ingredient in ingredients)
        {
            Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} - Calories: {ingredient.Calories} - Food Group: {ingredient.FoodGroup}");
        }
        Console.WriteLine("Steps:");
        for (int i = 0; i < steps.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {steps[i].Description}");
        }
    }

    public int CalculateTotalCalories()
    {
        return ingredients.Sum(i => i.Calories);
    }

    public void NotifyIfCaloriesExceedLimit(int limit)
    {
        if (CalculateTotalCalories() > limit)
        {
            Console.WriteLine("Warning: Total calories exceed the limit!");
        }
    }

    public void ClearData()
    {
        ingredients.Clear();
        steps.Clear();
    }
}

public enum FoodGroup
{
    Protein,
    Carbohydrate,
    Vegetable,
    Fruit,
    Dairy,
    Fat
}

class Program
{
    static void Main(string[] args)
    {
        List<Recipe> recipes = new List<Recipe>();

        while (true)
        {
            Console.WriteLine("Enter the name of the recipe (or type 'exit' to quit):");
            string recipeName = Console.ReadLine();

            if (recipeName.ToLower() == "exit")
            {
                break;
            }

            Recipe recipe = new Recipe { Name = recipeName };

            while (true)
            {
                Console.WriteLine("Enter the name of the ingredient (or type 'done' to finish adding ingredients):");
                string ingredientName = Console.ReadLine();

                if (ingredientName.ToLower() == "done")
                {
                    break;
                }

                Console.WriteLine("Enter the quantity:");
                double quantity = double.Parse(Console.ReadLine());

                Console.WriteLine("Enter the unit:");
                string unit = Console.ReadLine();

                Console.WriteLine("Enter the number of calories:");
                int calories = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter the food group (Protein, Carbohydrate, Vegetable, Fruit, Dairy, Fat):");
                FoodGroup foodGroup = (FoodGroup)Enum.Parse(typeof(FoodGroup), Console.ReadLine(), true);

                recipe.AddIngredient(ingredientName, quantity, unit, calories, foodGroup);
            }

            recipes.Add(recipe);
        }

        Console.WriteLine("List of recipes in alphabetical order:");
        foreach (var recipe in recipes.OrderBy(r => r.Name))
        {
            Console.WriteLine(recipe.Name);
        }

        Console.WriteLine("Enter the name of the recipe to display ingredients and total calories:");
        string selectedRecipeName = Console.ReadLine();
        Recipe selectedRecipe = recipes.FirstOrDefault(r => r.Name.ToLower() == selectedRecipeName.ToLower());

        if (selectedRecipe != null)
        {
            selectedRecipe.DisplayRecipe();
            int totalCalories = selectedRecipe.CalculateTotalCalories();
            Console.WriteLine($"Total calories: {totalCalories}");
            selectedRecipe.NotifyIfCaloriesExceedLimit(300);
        }
        else
        {
            Console.WriteLine("Recipe not found.");
        }
    }
}
