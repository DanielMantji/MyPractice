package com.example.mycollections;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Objects;

public class Dashboard extends AppCompatActivity {

    private long backPressedTime;
    private Toast backToast;
    FirebaseAuth mAuth;
    final float v = 0;
    LinearLayout add, view, editC, about, editB, logout;  //declaration of cardviews
    FirebaseUser user;
    String uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        TextView lblEmail = findViewById(R.id.lblEmail);
        mAuth = FirebaseAuth.getInstance();

        add = findViewById(R.id.Add);
        view = findViewById(R.id.View);
        editC = findViewById(R.id.EditC);
        editB = findViewById(R.id.EditB);
        about = findViewById(R.id.About);
        logout = findViewById(R.id.Logout);

        DashboardAnim();

        Add();
        View();
        EditBook();
        EditCategory();
        About();
        Logout();

        lblEmail.setText(Objects.requireNonNull(mAuth.getCurrentUser()).getEmail());

    }

    private void DashboardAnim()
    {
        add.setTranslationX(800);
        add.setAlpha(v);
        add.animate().translationX(0).alpha(1).setDuration(500).setStartDelay(650).start();

        view.setTranslationX(800);
        view.setAlpha(v);
        view.animate().translationX(0).alpha(1).setDuration(500).setStartDelay(550).start();

        editB.setTranslationX(800);
        editB.setAlpha(v);
        editB.animate().translationX(0).alpha(1).setDuration(500).setStartDelay(450).start();

        about.setTranslationY(800);
        about.setAlpha(v);
        about.animate().translationY(0).alpha(1).setDuration(500).setStartDelay(350).start();

        editC.setTranslationX(800);
        editC.setAlpha(v);
        editC.animate().translationX(0).alpha(1).setDuration(500).setStartDelay(250).start();

        logout.setTranslationX(800);
        logout.setAlpha(v);
        logout.animate().translationX(0).alpha(1).setDuration(500).setStartDelay(150).start();
    }

    private void Add()
    {
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent add = new Intent(Dashboard.this, AddCategory.class);
                startActivity(add);
            }
        });

    }
    private void View()
    {
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent V = new Intent(Dashboard.this, MyBooks.class);
                startActivity(V);
//                user = FirebaseAuth.getInstance().getCurrentUser();
//                uid = user.getUid();
//                Toast.makeText(getApplicationContext(), "Double press back again to exit" + uid,Toast.LENGTH_SHORT);
            }
        });
    }

    private void EditCategory()
    {
        editC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent EC = new Intent(Dashboard.this, ViewCategories.class);
                startActivity(EC);
            }
        });
    }

    private void EditBook()
    {
        editB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent EB = new Intent(Dashboard.this, EditBook.class);
                startActivity(EB);
            }
        });
    }

    private void About()
    {
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent A = new Intent(Dashboard.this, AboutUs.class);
                startActivity(A);
            }
        });
    }

    private void Logout()
    {
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                Intent A = new Intent(Dashboard.this, MainActivity.class);
                startActivity(A);
                finishAffinity();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null){
            startActivity(new Intent(Dashboard.this, MainActivity.class));
        }
    }

    @Override
    public void onBackPressed() {

        if(backPressedTime + 2000 > System.currentTimeMillis())
        {
            finish();
            backToast.cancel();
            super.onBackPressed();
            return;
        }
        else
        {
            backToast =  Toast.makeText(getBaseContext(), "Double press back again to exit",Toast.LENGTH_SHORT);
            backToast.show();
        }
        backPressedTime = System.currentTimeMillis();
    }
}