package com.example.mycollections;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class ViewOneBook extends AppCompatActivity {
    Handler mainHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_view_one_book);

        Intent intent = getIntent();

        TextView title, date, desc;

        title = findViewById(R.id.lblTitle);
        date = findViewById(R.id.lblDate);
        desc = findViewById(R.id.lblDesc);
        ImageView img = findViewById(R.id.img);

        title.setText(intent.getStringExtra("name"));
        date.setText(intent.getStringExtra("date"));
        desc.setText(intent.getStringExtra("desc"));

        new FetchImage(intent.getStringExtra("img"), img).start();
    }

    class FetchImage extends Thread{

        String URL;
        Bitmap bitmap;
        ImageView img;

        FetchImage(String URL, ImageView img){

            this.URL = URL;
            this.img = img;

        }

        @Override
        public void run() {

            mainHandler.post(new Runnable() {
                @Override
                public void run() {


                }
            });

            InputStream inputStream = null;
            try {
                inputStream = new URL(URL).openStream();
                bitmap = BitmapFactory.decodeStream(inputStream);
            } catch (IOException e) {
                e.printStackTrace();
            }

            mainHandler.post(new Runnable() {
                @Override
                public void run() {

//                    holder.img.setImageDrawable(LoadImageFromWebOperations());
                    img.setImageBitmap(bitmap);

                }
            });




        }
    }
}

