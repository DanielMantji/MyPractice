package com.example.mycollections;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;


public class AddCategory_Fragment extends Fragment {

    private ProgressBar progressBar;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceSate)
    {
        View view = inflater.inflate(R.layout.fragment_add_category_,container,false);

        AppCompatButton upload = view.findViewById(R.id.Upload);
        EditText eve = view.findViewById(R.id.en);
        EditText shm = view.findViewById(R.id.sm);

        progressBar = (ProgressBar) view.findViewById(R.id.progress);

        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Name  = eve.getText().toString();
                String number = shm.getText().toString();

                Category cate = new Category(Name, number, "0");
                progressBar.setVisibility(View.VISIBLE);
                FirebaseDatabase.getInstance().getReference("users")
                        .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("category").child(Name)
                        .setValue(cate).addOnCompleteListener(new OnCompleteListener<Void>()
                        {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful())
                                {
                                    Toast.makeText(getContext(), "New Category Added", Toast.LENGTH_LONG).show();

                                    progressBar.setVisibility(View.GONE);
                                    eve.setText("");
                                    shm.setText("");
                                }
                                else
                                {
                                    Toast.makeText(getContext(), "Failed, try again", Toast.LENGTH_LONG).show();
                                    progressBar.setVisibility(View.GONE);
                                }
                            }
                        });
            }
        });
        return view;
    }

}