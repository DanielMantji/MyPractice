package com.example.mycollections;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ViewCategories extends AppCompatActivity {

    RecyclerView recyclerView;
    DatabaseReference database;
    MyCatAdapter myCatAdapter;
    ArrayList<Category> list;

    TextView lbl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_categories);


        recyclerView = findViewById(R.id.userList);
        database = FirebaseDatabase.getInstance().getReference("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("category");
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        lbl = findViewById(R.id.lblLa);

        list = new ArrayList<>();
        myCatAdapter = new MyCatAdapter(this,list);
        recyclerView.setAdapter(myCatAdapter);

        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot dataSnapshot : snapshot.getChildren()){

                    Category user = dataSnapshot.getValue(Category.class);
                    if(user != null){
                        user.setItemscollected(String.valueOf(GetBooksCollected(user.name)));
                    }


                    list.add(user);
                }

                if(!list.isEmpty()){
                    lbl.setVisibility(View.INVISIBLE);
                }

                myCatAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private int GetBooksCollected(String category){

        final int[] count = {0};
        final int[] cosunt = new int[1];
        FirebaseDatabase.getInstance().getReference("users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .child("books")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        for (DataSnapshot dataSnapshot : snapshot.getChildren()){

                            BookDetails user = dataSnapshot.getValue(BookDetails.class);

                            if(dataSnapshot.getKey().equalsIgnoreCase(category)){
                                count[0]++;

                            }
                        }
                        cosunt[0] = count[0];
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        return cosunt[0];
    }
}