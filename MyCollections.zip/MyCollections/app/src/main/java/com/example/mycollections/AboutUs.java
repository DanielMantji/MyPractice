package com.example.mycollections;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

public class AboutUs extends AppCompatActivity {

    DrawerLayout drawerLayout;
    TextView usersname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);

        drawerLayout = findViewById(R.id.DrawerLayout);
        //usersname = findViewById(R.id.TheName);
    }


    @Override
    protected void onPause() {
        super.onPause();

    }
    public void ClickPP(View view) {
    }

    public void ClickLicenses(View view) {
    }

    public void ZWTwitter(View view) {
    }

    public void ZWFacebook(View view) {
    }

    public void ZWGmail(View view) {
    }

    public void SfTwitter(View view) {
    }

    public void SfCall(View view) {
    }

    public void SfFacebook(View view) {
    }

    public void SfGmail(View view) {
    }

    public void BGmail(View view) {
    }

    public void RDCall(View view) {
    }

    public void RDFacebook(View view) {
    }

    public void RDGmail(View view) {
    }


    public void SfInstagram(View view) {
    }

    public void ZWInstagram(View view) {
    }
}