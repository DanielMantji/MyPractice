package com.example.mycollections;

public class Category {


    public String name, numberofcollections, itemscollected;

    public Category(String name, String numberofcollections, String itemscollected) {
        this.name = name;
        this.numberofcollections = numberofcollections;
        this.itemscollected = itemscollected;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumberofcollections() {
        return numberofcollections;
    }

    public void setNumberofcollections(String numberofcollections) {
        this.numberofcollections = numberofcollections;
    }

    public String getItemscollected() {
        return itemscollected;
    }

    public void setItemscollected(String itemscollected) {
        this.itemscollected = itemscollected;
    }

    public Category() {
    }
}
