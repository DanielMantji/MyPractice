package com.example.mycollections;
import static androidx.core.content.ContextCompat.startActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    Context context;
//    ActivityMainBinding binding;
    Handler mainHandler = new Handler();

    ArrayList<BookDetails> list;

    public MyAdapter(Context context, ArrayList<BookDetails> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item,parent,false);
        return  new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        BookDetails user = list.get(position);
        holder.Name.setText(user.getName());
        holder.date.setText(user.getDate());
        holder.desc.setText(user.getDesc());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ViewOneBook.class);
                intent.putExtra("name", holder.Name.getText().toString());
                intent.putExtra("date", holder.date.getText().toString());
                intent.putExtra("desc", holder.desc.getText().toString());
                intent.putExtra("img", user.getImg());


                context.startActivity(intent);
            }
        });

        new FetchImage(user.getImg(), holder.img).start();




    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView Name, date, desc;
        ImageView img;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            Name = itemView.findViewById(R.id.tvfirstName);
            date = itemView.findViewById(R.id.tvlastName);
            desc = itemView.findViewById(R.id.tvage);
            img = itemView.findViewById(R.id.img);



        }
    }

    class FetchImage extends Thread{

        String URL;
        Bitmap bitmap;
        ImageView img;

        FetchImage(String URL, ImageView img){

            this.URL = URL;
            this.img = img;

        }

        @Override
        public void run() {

            mainHandler.post(new Runnable() {
                @Override
                public void run() {


                }
            });

            InputStream inputStream = null;
            try {
                inputStream = new URL(URL).openStream();
                bitmap = BitmapFactory.decodeStream(inputStream);
            } catch (IOException e) {
                e.printStackTrace();
            }

            mainHandler.post(new Runnable() {
                @Override
                public void run() {

//                    holder.img.setImageDrawable(LoadImageFromWebOperations());
                    img.setImageBitmap(bitmap);

                }
            });




        }
    }

}
