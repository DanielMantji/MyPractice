package com.example.mycollections;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp extends AppCompatActivity {
    private ProgressBar progressBar;
     EditText txt1, txt3, txt4, txt5;
    private FirebaseAuth mAuth;
    private String str1, str2, str3, str4, str5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        mAuth = FirebaseAuth.getInstance();

        AppCompatButton btn_submit = findViewById(R.id.SignUpButton);
         txt1 = findViewById(R.id.SName);
        txt3 = findViewById(R.id.SEmail);
         txt4 = findViewById(R.id.SPassword);
         txt5 = findViewById(R.id.SCPassword);

         progressBar = (ProgressBar) findViewById(R.id.progress);

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mRegister();
            }
        });
    }

    private void mRegister()
    {
        str1 = txt1.getText().toString();
        str3 = txt3.getText().toString();
        str4 = txt4.getText().toString();
        str5 = txt5.getText().toString();

        if(txt1.getText().toString().isEmpty())
        {
            txt1.setError("This field cannot be empty");
        }
        else if(txt3.getText().toString().isEmpty())
        {
            txt3.setError("This field cannot be empty");
        }
        else if(txt4.getText().toString().isEmpty())
        {
            txt4.setError("This field cannot be empty");
        }
        else if(txt5.getText().toString().isEmpty())
        {
            txt5.setError("This field cannot be empty");
        }
        else if(!txt5.getText().toString().equals(txt4.getText().toString()))
        {
            txt5.setError("Passwords don't match");
        }
        else
        {
            progressBar.setVisibility(View.VISIBLE);
                    mAuth.createUserWithEmailAndPassword(str3,str4)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>()
                            {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful())
                                    {
                                        Users user = new Users(str1, str2, str3);
                                        FirebaseDatabase.getInstance().getReference("users")
                                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>()
                                                {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if(task.isSuccessful())
                                                        {
                                                            Toast.makeText(getApplicationContext(), "User Registered successfully", Toast.LENGTH_LONG).show();
                                                            Intent Dash = new Intent(SignUp.this, Dashboard.class);
                                                            startActivity(Dash);
                                                            progressBar.setVisibility(View.GONE);
                                                        }
                                                        else
                                                        {
                                                            Toast.makeText(getApplicationContext(), "Failed, try again", Toast.LENGTH_LONG).show();
                                                            progressBar.setVisibility(View.GONE);
                                                        }
                                                    }
                                                });
                                    }
                                    else
                                    {
                                        Toast.makeText(getApplicationContext(), "Registration Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                        progressBar.setVisibility(View.GONE);
                                    }
                                }
                            });
        }
    }
}