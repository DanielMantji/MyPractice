package com.example.mycollections;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    EditText email, password;
    TextView signup, signin, forgot;
    FloatingActionButton login;
    private ProgressBar progressBar;
    String Email, Password, uid;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();

        login = findViewById(R.id.Login);
        email = findViewById(R.id.Email);
        password = findViewById(R.id.Password);
        signup = findViewById(R.id.SignUp);
        signin = findViewById(R.id.SignIn);
        forgot = findViewById(R.id.ForgotPassword);

        progressBar = (ProgressBar) findViewById(R.id.progress);

        Anim();
        Login();
        SignUp();
    }

    private void Anim()
    {
        email.setTranslationX(800);
        email.setAlpha(0);
        email.animate().translationX(0).alpha(1).setDuration(500).setStartDelay(350).start();

        password.setTranslationX(800);
        password.setAlpha(0);
        password.animate().translationX(0).alpha(1).setDuration(500).setStartDelay(350).start();

        signup.setTranslationX(800);
        signup.setAlpha(0);
        signup.animate().translationX(0).alpha(1).setDuration(500).setStartDelay(450).start();

        signin.setTranslationX(800);
        signin.setAlpha(0);
        signin.animate().translationX(0).alpha(1).setDuration(500).setStartDelay(450).start();

        forgot.setTranslationX(800);
        forgot.setAlpha(0);
        forgot.animate().translationX(0).alpha(1).setDuration(500).setStartDelay(250).start();
    }

    private void SignUp()
    {
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signUp = new Intent(MainActivity.this, SignUp.class);
                startActivity(signUp);
            }
        });
    }

    private void Login()
    {
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Email = email.getText().toString();
                Password = password.getText().toString();

                if(email.getText().toString().isEmpty())
                {
                    email.setError("This field cannot be empty");
                }
                else if(password.getText().toString().isEmpty())
                {
                    password.setError("This field cannot be empty");
                }
                else
                {
                    progressBar.setVisibility(View.VISIBLE);
                    mAuth.signInWithEmailAndPassword(Email,Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task)
                        {

                            if(task.isSuccessful())
                            {
                                Intent Dash = new Intent(MainActivity.this, Dashboard.class);
                                startActivity(Dash);
                                progressBar.setVisibility(View.GONE);
                            }
                            else
                            {
                                Toast.makeText(MainActivity.this, "Log in Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.GONE);
                            }
                        }
                    });
                }
            }
        });
    }
}