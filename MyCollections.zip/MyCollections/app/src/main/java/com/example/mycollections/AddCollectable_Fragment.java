package com.example.mycollections;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.Calendar;
import java.util.UUID;

public class AddCollectable_Fragment extends Fragment{
    private ProgressBar progressBar;
    ImageView stombe;
    private Uri imageUri;

    private static final int PICK_IMAGE = 1;
    UploadTask uploadTask;
    FirebaseStorage firebaseStorage;
    StorageReference storageReference;

    EditText eve;
    EditText org;
    EditText shm;
    TextView dDate;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceSate)
    {
        View view = inflater.inflate(R.layout.fragment_add_collectable_,container,false);

        AppCompatButton upload = view.findViewById(R.id.Upload);
        stombe = view.findViewById(R.id.img);
         eve = view.findViewById(R.id.en);
         org = view.findViewById(R.id.or);
         shm = view.findViewById(R.id.sm);
         dDate = view.findViewById(R.id.dt);

        firebaseStorage = FirebaseStorage.getInstance();
        storageReference = firebaseStorage.getReference();

        progressBar = (ProgressBar) view.findViewById(R.id.progress);

        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        dDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener(){

                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month = month+1;
                        String date = day + "/" + month +"/" +year;
                        dDate.setText(date);
                    }
                }, year, month,day);
                datePickerDialog.show();
            }
        });

        stombe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent gallery = new Intent();
                gallery.setType("image/*");
                gallery.setAction(Intent.ACTION_GET_CONTENT);

                startActivityForResult(Intent.createChooser(gallery, "Select Picture"), PICK_IMAGE);
            }
        });

        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Name  = eve.getText().toString();
                String Date = dDate.getText().toString();
                String category = org.getText().toString();
                String description = shm.getText().toString();
                //byte[] Poster = ImageViewToByte(stombe);

                if(Name.isEmpty())
                {
                    eve.setError("This field cannot be empty");
                }
                else if(Date.isEmpty())
                {
                    dDate.setError("This field cannot be empty");
                }
                else if(category.isEmpty())
                {
                    org.setError("This field cannot be empty");
                }
                else if(description.isEmpty())
                {
                    shm.setError("This field cannot be empty");
                }
                else
                {
                    Books books = new Books(Name, Date, description, "");
                    UploadImage(books);
                    progressBar.setVisibility(View.VISIBLE);
                }
            }
        });
        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == PICK_IMAGE && resultCode == getActivity().RESULT_OK) {

            try {
                imageUri = data.getData();
                stombe.setImageURI(imageUri);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void UploadImage(Books books){
        final String key = String.valueOf(UUID.randomUUID());
        final StorageReference ref = storageReference.child("images/"+key);
        uploadTask = ref.putFile(imageUri);

        Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
            @Override
            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                if (!task.isSuccessful()) {
                    throw task.getException();
                }

                // Continue with the task to get the download URL
                return ref.getDownloadUrl();
            }
        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                if (task.isSuccessful()) {
                    Uri downloadUri = task.getResult();
                    books.setImg(String.valueOf(downloadUri));
                    mUploadData(books);

                } else {
                    Toast.makeText(getContext(), "failed to save image", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void mUploadData(Books books){
        FirebaseDatabase.getInstance().getReference("users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("books").child(books.getName())
                .setValue(books).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful())
                        {
                            Toast.makeText(getContext(), "New Book Added", Toast.LENGTH_LONG).show();
                            progressBar.setVisibility(View.GONE);
                            eve.setText("");
                            dDate.setText("");
                            org.setText("");
                            shm.setText("");
                            stombe.setImageDrawable(null);
                        }
                        else {
                            Toast.makeText(getContext(), "Failed, try again", Toast.LENGTH_LONG).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });
    }

}