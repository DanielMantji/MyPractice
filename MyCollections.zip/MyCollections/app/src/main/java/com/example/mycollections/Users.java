package com.example.mycollections;

public class Users {

    public String name, number, email;

    public Users(String name, String number, String email) {
        this.name = name;
        this.number = number;
        this.email = email;
    }


    public Users() {
    }
}
